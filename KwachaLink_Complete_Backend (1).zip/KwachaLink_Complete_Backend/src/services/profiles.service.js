const {dbError}=require('./base.service');
async function get(db,id){const r=await db.from('profiles').select('id,display_name,bio,country,preferred_currency,avatar_url,created_at,updated_at').eq('id',id).maybeSingle();if(r.error)throw dbError(r.error);return r.data;}
async function update(db,id,data){const allowed={};for(const k of ['display_name','bio','country','preferred_currency','avatar_url'])if(data[k]!==undefined)allowed[k]=data[k];allowed.updated_at=new Date().toISOString();const r=await db.from('profiles').upsert({id,...allowed},{onConflict:'id'}).select('id,display_name,bio,country,preferred_currency,avatar_url,created_at,updated_at').single();if(r.error)throw dbError(r.error);return r.data;}
module.exports={get,update};
