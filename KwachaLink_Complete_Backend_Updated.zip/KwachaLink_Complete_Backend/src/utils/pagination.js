function pagination(query) { const page=Math.max(1,Math.min(100000,Number.parseInt(query.page,10)||1)); const limit=Math.max(1,Math.min(100,Number.parseInt(query.limit,10)||20)); return {page,limit,from:(page-1)*limit,to:(page-1)*limit+limit-1}; }
module.exports={pagination};
