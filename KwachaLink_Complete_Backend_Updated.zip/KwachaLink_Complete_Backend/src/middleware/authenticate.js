const { supabase, userClient } = require('../config/supabase');
const { failure } = require('../utils/apiResponse');
module.exports = async function authenticate(req,res,next) {
 const h=req.get('authorization')||''; const m=h.match(/^Bearer\s+(.+)$/i); if(!m) return failure(res,401,'AUTH_REQUIRED','A valid Bearer access token is required.');
 try { const {data,error}=await supabase.auth.getUser(m[1]); if(error||!data.user) return failure(res,401,'INVALID_TOKEN','Access token is invalid or expired.'); req.user=data.user; req.accessToken=m[1]; req.db=userClient(m[1]); next(); } catch { return failure(res,401,'AUTH_FAILED','Authentication could not be verified.'); }
};
