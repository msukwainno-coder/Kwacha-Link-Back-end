const {failure}=require('../utils/apiResponse');
module.exports=(schema,source='body')=>(req,res,next)=>{const parsed=schema.safeParse(req[source]); if(!parsed.success) return failure(res,400,'VALIDATION_ERROR','Request validation failed.',parsed.error.issues.map(i=>({path:i.path.join('.'),message:i.message}))); req[source]=parsed.data; next();};
