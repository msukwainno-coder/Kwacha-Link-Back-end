const env=require('../config/env'); const {failure}=require('../utils/apiResponse');
module.exports={admin:(req,res,next)=>{if(!req.user||!env.ADMIN_ID_LIST.includes(req.user.id)) return failure(res,403,'FORBIDDEN','Administrator access required.'); next();}};
