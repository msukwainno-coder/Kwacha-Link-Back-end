const {failure}=require('../utils/apiResponse'); module.exports=(req,res)=>failure(res,404,'NOT_FOUND','The requested endpoint does not exist.');
