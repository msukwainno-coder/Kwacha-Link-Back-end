const rateLimit=require('express-rate-limit'); const env=require('../config/env');
const standard={standardHeaders:'draft-8',legacyHeaders:false,handler:(req,res)=>res.status(429).json({success:false,error:{code:'RATE_LIMITED',message:'Too many requests. Please try again later.'}})};
module.exports={globalLimiter:rateLimit({...standard,windowMs:15*60*1000,limit:env.GLOBAL_RATE_LIMIT_MAX}),writeLimiter:rateLimit({...standard,windowMs:15*60*1000,limit:env.WRITE_RATE_LIMIT_MAX}),authLimiter:rateLimit({...standard,windowMs:15*60*1000,limit:10})};
