const { pagination }=require('../utils/pagination');
async function listTable(db,table,query,columns='*',order='created_at'){const p=pagination(query);let q=db.from(table).select(columns,{count:'exact'}).order(order,{ascending:false}).range(p.from,p.to);return q;}
function dbError(error){const e=new Error(error?.message||'Database operation failed');e.status=error?.code==='23505'?409: error?.code==='42501'?403:400;e.code=error?.code==='23505'?'CONFLICT':error?.code==='42501'?'FORBIDDEN':'DATABASE_ERROR';return e;}
module.exports={listTable,dbError};
