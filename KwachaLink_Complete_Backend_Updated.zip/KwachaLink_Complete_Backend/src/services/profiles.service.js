const {dbError}=require('./base.service');
const COLS='id,full_name,email,phone,country,bio,avatar_url,verification_status,created_at';
function api(r){if(!r)return r;return {...r,display_name:r.full_name};}
async function get(db,id){const r=await db.from('profiles').select(COLS).eq('id',id).maybeSingle();if(r.error)throw dbError(r.error);return api(r.data);}
async function update(db,id,data){const x={};if(data.display_name!==undefined)x.full_name=data.display_name;if(data.bio!==undefined)x.bio=data.bio;if(data.country!==undefined)x.country=data.country;if(data.avatar_url!==undefined)x.avatar_url=data.avatar_url;if(data.phone!==undefined)x.phone=data.phone;const {data:user}=await db.auth.getUser();if(user?.user?.email)x.email=user.user.email;const r=await db.from('profiles').upsert({id,...x},{onConflict:'id'}).select(COLS).single();if(r.error)throw dbError(r.error);return api(r.data);}
module.exports={get,update};
