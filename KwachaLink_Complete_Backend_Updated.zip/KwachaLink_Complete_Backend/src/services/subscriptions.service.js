const {dbError}=require('./base.service');
const COLS='id,user_id,plan_name,amount_mwk,status,starts_at,expires_at,payment_reference,created_at';
function api(r){if(!r)return r;return {...r,plan:r.plan_name,started_at:r.starts_at};}
async function mine(db,userId){const r=await db.from('subscriptions').select(COLS).eq('user_id',userId).order('created_at',{ascending:false});if(r.error)throw dbError(r.error);return (r.data||[]).map(api);}
async function request(db,userId,d){const r=await db.from('subscriptions').insert({user_id:userId,plan_name:'monthly',amount_mwk:4999,status:'pending',payment_reference:d.payment_reference||null}).select(COLS).single();if(r.error)throw dbError(r.error);return api(r.data);}
async function isActive(db,userId){const r=await db.from('subscriptions').select('id').eq('user_id',userId).eq('status','active').gt('expires_at',new Date().toISOString()).limit(1);if(r.error)throw dbError(r.error);return (r.data||[]).length>0;}
module.exports={mine,request,isActive};
