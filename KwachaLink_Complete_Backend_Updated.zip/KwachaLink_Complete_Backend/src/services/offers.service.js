const { dbError } = require('./base.service');

// Database schema compatibility layer. The current Supabase offers table uses:
// user_id, offer_type, currency_from, currency_to, amount, country, created_at.
// Keep the public API's existing field names so the frontend contract stays stable.
const DB_COLUMNS = 'id,user_id,offer_type,currency_from,currency_to,exchange_rate,amount,remaining_amount,country,description,status,created_at';
function toApi(row) {
  if (!row) return row;
  return {
    id: row.id,
    owner_id: row.user_id,
    direction: row.offer_type,
    source_currency: row.currency_from,
    target_currency: row.currency_to,
    exchange_rate: row.exchange_rate,
    original_amount: row.amount,
    remaining_amount: row.remaining_amount,
    description: row.description,
    location: row.country,
    status: row.status,
    created_at: row.created_at
  };
}
function toDb(data) {
  const out = {};
  if (data.direction !== undefined) out.offer_type = data.direction;
  if (data.source_currency !== undefined) out.currency_from = data.source_currency.toUpperCase();
  if (data.target_currency !== undefined) out.currency_to = data.target_currency.toUpperCase();
  if (data.exchange_rate !== undefined) out.exchange_rate = data.exchange_rate;
  if (data.original_amount !== undefined) out.amount = data.original_amount;
  if (data.remaining_amount !== undefined) out.remaining_amount = data.remaining_amount;
  if (data.description !== undefined) out.description = data.description;
  if (data.location !== undefined) out.country = data.location;
  if (data.status !== undefined) out.status = data.status;
  return out;
}
async function list(db, q) {
  let x = db.from('offers').select(DB_COLUMNS, { count: 'exact' }).eq('status', 'active').order('created_at', { ascending: false });
  if (q.source_currency) x = x.eq('currency_from', q.source_currency.toUpperCase());
  if (q.target_currency) x = x.eq('currency_to', q.target_currency.toUpperCase());
  if (q.direction) x = x.eq('offer_type', q.direction);
  if (q.location) x = x.ilike('country', `%${q.location}%`);
  if (q.min_rate) x = x.gte('exchange_rate', q.min_rate);
  if (q.max_rate) x = x.lte('exchange_rate', q.max_rate);
  if (q.min_amount) x = x.gte('remaining_amount', q.min_amount);
  if (q.search) x = x.ilike('description', `%${q.search}%`);
  const page = Math.max(1, Number(q.page) || 1), limit = Math.min(100, Math.max(1, Number(q.limit) || 20));
  const r = await x.range((page - 1) * limit, page * limit - 1);
  if (r.error) throw dbError(r.error);
  return { items: (r.data || []).map(toApi), total: r.count, page, limit };
}
async function get(db, id) {
  const r = await db.from('offers').select(DB_COLUMNS).eq('id', id).maybeSingle();
  if (r.error) throw dbError(r.error);
  if (!r.data) { const e = new Error('Offer not found'); e.status = 404; throw e; }
  return toApi(r.data);
}
async function create(db, userId, d) {
  const payload = { ...toDb(d), user_id: userId, remaining_amount: d.original_amount, status: 'active' };
  const r = await db.from('offers').insert(payload).select(DB_COLUMNS).single();
  if (r.error) throw dbError(r.error);
  return toApi(r.data);
}
async function update(db, id, userId, d) {
  const r = await db.from('offers').update(toDb(d)).eq('id', id).eq('user_id', userId).in('status', ['active', 'paused']).select(DB_COLUMNS).maybeSingle();
  if (r.error) throw dbError(r.error);
  if (!r.data) { const e = new Error('Offer not found, not owned by you, or no longer editable'); e.status = 404; throw e; }
  return toApi(r.data);
}
async function status(db, id, userId, statusValue) {
  const r = await db.from('offers').update({ status: statusValue }).eq('id', id).eq('user_id', userId).in('status', ['active', 'paused']).select(DB_COLUMNS).maybeSingle();
  if (r.error) throw dbError(r.error);
  if (!r.data) { const e = new Error('Offer not found or cannot change status'); e.status = 404; throw e; }
  return toApi(r.data);
}
module.exports = { list, get, create, update, status, PUBLIC: DB_COLUMNS };
