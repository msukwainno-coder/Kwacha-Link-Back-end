const { z } = require('zod');
require('dotenv').config();
const schema = z.object({
 NODE_ENV: z.enum(['development','test','production']).default('development'),
 PORT: z.coerce.number().int().min(1).max(65535).default(10000),
 SUPABASE_URL: z.string().url().refine(v => v.startsWith('https://'), 'SUPABASE_URL must use HTTPS'),
 SUPABASE_PUBLISHABLE_KEY: z.string().min(1),
 SUPABASE_SECRET_KEY: z.string().optional().default(''),
 CORS_ORIGINS: z.string().default('https://msukwainno-coder.github.io,http://localhost:5500,http://127.0.0.1:5500'),
 ADMIN_USER_IDS: z.string().optional().default(''),
 GLOBAL_RATE_LIMIT_MAX: z.coerce.number().int().positive().default(120),
 WRITE_RATE_LIMIT_MAX: z.coerce.number().int().positive().default(30)
});
const parsed = schema.safeParse(process.env);
if (!parsed.success) { console.error('Invalid environment configuration:', parsed.error.issues.map(i => `${i.path.join('.')}: ${i.message}`).join('; ')); process.exit(1); }
module.exports = Object.freeze({...parsed.data, CORS_ORIGIN_LIST: parsed.data.CORS_ORIGINS.split(',').map(s=>s.trim()).filter(Boolean), ADMIN_ID_LIST: parsed.data.ADMIN_USER_IDS.split(',').map(s=>s.trim()).filter(Boolean)});
