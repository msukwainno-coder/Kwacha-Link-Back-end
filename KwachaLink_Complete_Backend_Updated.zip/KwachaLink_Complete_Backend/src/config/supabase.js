const { createClient } = require('@supabase/supabase-js');
const env = require('./env');
// Public/publishable key client only. Requests are user-scoped after token verification; RLS remains enabled.
const supabase = createClient(env.SUPABASE_URL, env.SUPABASE_PUBLISHABLE_KEY, { auth: { persistSession:false, autoRefreshToken:false, detectSessionInUrl:false } });
function userClient(accessToken) { return createClient(env.SUPABASE_URL, env.SUPABASE_PUBLISHABLE_KEY, { global:{headers:{Authorization:`Bearer ${accessToken}`}}, auth:{persistSession:false,autoRefreshToken:false,detectSessionInUrl:false} }); }
module.exports = { supabase, userClient };
