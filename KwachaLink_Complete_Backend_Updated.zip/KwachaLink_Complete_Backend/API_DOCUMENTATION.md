# API Documentation

Base URL: `https://YOUR-RENDER-SERVICE.onrender.com/api/v1`. JSON requests. Protected endpoints require `Authorization: Bearer <Supabase access token>`. Standard success: `{"success":true,"data":...}`; paginated success adds `meta:{total,page,limit}`. Errors: `{"success":false,"error":{"code":"...","message":"..."}}`. Validation errors may include field paths. Server errors do not expose SQL details.

## Health
- `GET /health` (also root `/health`): public, 200 status.
- `GET /api/v1/health`: public.

## Profiles
- `GET /profiles/me` — auth; own profile.
- `PATCH /profiles/me` — auth; optional `display_name`, `bio`, `country`, `preferred_currency` (3 chars), `avatar_url`.
- `GET /profiles/:id` — auth; public profile fields only. Contact details are never returned here.

## Offers
- `GET /offers` — public; query `source_currency`, `target_currency`, `direction=buy|sell`, `location`, `min_rate`, `max_rate`, `min_amount`, `search`, `page`, `limit`.
- `GET /offers/:id` — public; offer detail, subject to RLS.
- `POST /offers` — auth; required `direction`, `source_currency`, `target_currency`, `exchange_rate`, `original_amount`; optional `description`, `location`. Remaining amount starts equal to original amount.
- `PATCH /offers/:id` — auth, owner only; `exchange_rate`, `description`, `location`.
- `POST /offers/:id/pause`, `/resume`, `/cancel` — auth, owner only.

## Connections
- `GET /connections` — auth; participant connections.
- `POST /connections` — auth; `{ "offer_id":"uuid" }`.
- `POST /connections/:id/accept` and `/reject` — auth, offer owner only for pending requests.
- `POST /connections/:id/cancel` — auth, requester only for pending request.

## Messages
- `GET /messages/connection/:connectionId?page=1&limit=30` — auth, connection participant only.
- `POST /messages` — auth; `{ "connection_id":"uuid", "content":"..." }`; requires accepted connection. Messages are limited to 4,000 characters.

## Deals
- `GET /deals` — auth; own deals.
- `POST /deals` — auth; `{ "connection_id":"uuid", "buyer_id":"uuid", "seller_id":"uuid", "amount":100, "agreed_rate":... }`; identities must match the accepted connection and offer owner.
- `POST /deals/:id/confirm` — auth, buyer or seller; each may confirm only their own side. Only the second confirmation completes the deal and atomically deducts the offer amount through PostgreSQL RPC.
- `POST /deals/:id/cancel` — auth, participant; pending deals only.
- `POST /deals/:id/dispute` — auth, participant.

## Subscriptions
- `GET /subscriptions/me` — auth; own subscription history.
- `GET /subscriptions/contact-access` — auth; returns `can_reveal_contact` and monthly fee `4999` MWK.
- `POST /subscriptions` — auth; `{ "plan":"monthly", "payment_reference":"optional reference" }`; creates pending request only.
- `POST /subscriptions/admin/:id/activate` — auth and server allowlist (`ADMIN_USER_IDS`) plus server-only `SUPABASE_SECRET_KEY`; manual audited activation. Configure only for trusted administrators; prefer provider webhook verification when a gateway is selected. No public self-activation.

## Reviews
- `GET /reviews/user/:userId?page=1&limit=20` — auth; public review list.
- `POST /reviews` — auth; `{ "deal_id":"uuid", "reviewed_user_id":"uuid", "rating":1-5, "comment":"optional" }`; completed deal participant only; unique reviewer/deal.

## Auth flows
Registration, login, refresh, logout and password recovery are Supabase Auth operations, not API routes. Use Supabase JS `auth.signUp`, `auth.signInWithPassword`, `auth.resetPasswordForEmail`, `auth.signOut`, and pass `session.access_token` to protected API calls. Set allowed redirect URLs in Supabase Auth settings.

## Error codes
`AUTH_REQUIRED`, `INVALID_TOKEN`, `VALIDATION_ERROR`, `NOT_FOUND`, `FORBIDDEN`, `CONFLICT`, `RATE_LIMITED`, `DATABASE_ERROR`, `INTERNAL_ERROR`. Statuses normally 400, 401, 403, 404, 409, 429 or 500.
