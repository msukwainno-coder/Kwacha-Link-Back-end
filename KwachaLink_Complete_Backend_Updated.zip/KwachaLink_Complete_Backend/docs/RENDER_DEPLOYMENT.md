# Render deployment

1. Push this backend folder to a separate GitHub repository (recommended `kwachaLink-backend`).
2. In Render choose **New + → Web Service**, connect that repository, and use:
   - Runtime: Node
   - Build Command: `npm ci`
   - Start Command: `npm start`
   - Health Check Path: `/health`
3. Add environment variables in Render → service → Environment:
   - `NODE_ENV` = `production`
   - `SUPABASE_URL` = `https://pzcudjyjfohlrwkefkhb.supabase.co` (confirm project URL in Supabase settings)
   - `SUPABASE_PUBLISHABLE_KEY` = your project's publishable key (or legacy anon public key)
   - `CORS_ORIGINS` = `https://msukwainno-coder.github.io` (add local origins only if needed; comma-separated)
   - `ADMIN_USER_IDS` = trusted administrator Auth UUIDs only; leave blank if not using manual activation
   - `SUPABASE_SECRET_KEY` = optional server-only secret key, only if enabling the admin activation route. Never share it or put it in frontend/GitHub.
4. Deploy. Open `https://YOUR-SERVICE.onrender.com/health`; expect `success:true`.
5. Test auth and database endpoints with two test accounts. A successful health response only proves the HTTP process is running, not database connectivity.

Render deployment has not been performed by this package generator. Keep environment variables in Render, not committed files. Free instance cold starts may delay the first request.
