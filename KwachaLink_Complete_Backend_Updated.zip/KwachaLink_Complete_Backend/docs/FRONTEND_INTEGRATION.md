# Frontend integration

Do not replace the existing HTML/CSS/JS. Once Render deploys, set the API base URL in a small section of existing `script.js` or a separate `api.js` loaded by relevant pages. Replace `https://YOUR-SERVICE.onrender.com` with the real URL:

```js
const API_BASE = 'https://YOUR-SERVICE.onrender.com/api/v1';
async function apiRequest(path, { token, method = 'GET', body } = {}) {
  const response = await fetch(`${API_BASE}${path}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      ...(token ? { Authorization: `Bearer ${token}` } : {})
    },
    ...(body ? { body: JSON.stringify(body) } : {})
  });
  const payload = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(payload?.error?.message || `Request failed (${response.status})`);
  return payload.data;
}
// Example: const result = await apiRequest('/offers?source_currency=USD&target_currency=MWK');
```

Use Supabase JS in the frontend with the publishable/anon key only for Auth; never embed secret/service-role keys. For sign-in, `const {data,error}=await supabase.auth.signInWithPassword({email,password})`; use `data.session.access_token` in `apiRequest`. For sign-up use `supabase.auth.signUp`; password reset uses `supabase.auth.resetPasswordForEmail(email,{redirectTo:...})`; logout uses `supabase.auth.signOut()`.

Integration steps: (1) inspect current `script.js` to identify localStorage/sample offer functions; (2) change `explore.html` flow to GET `/offers`; (3) change `post.html` to POST `/offers` with token; (4) connect `register.html`/`login.html` to Supabase Auth; (5) change `messages.html` to use connections/messages routes; (6) profile page uses `/profiles/me`; (7) add loading/error/empty states and never display private contact fields until `/subscriptions/contact-access` says access is permitted and server policy supports actual reveal. No frontend files have been changed by this backend package.
