# Troubleshooting

- **Server exits at startup:** verify Node 20+, `npm ci`, and all required environment variables. Run `npm run check:env`.
- **CORS error:** set `CORS_ORIGINS` to the exact site origin, no trailing slash. GitHub Pages origin is `https://msukwainno-coder.github.io`, not the page URL path.
- **401:** refresh/login with Supabase Auth and send `Authorization: Bearer <access_token>`; do not send refresh token.
- **403/RLS error:** verify token belongs to intended user and review all existing RLS policies. Never fix by disabling RLS.
- **Column/table not found:** run inspection SQL and compare schema. Migrations may not fit pre-existing tables; stop and make a reviewed additive migration.
- **Deal RPC error:** confirm migration 010 applied, RLS is enabled, function grants are present, and the request token belongs to one of the deal participants.
- **Subscription not active:** expected until trusted admin activation or a verified provider integration is implemented. A user-entered payment reference is not proof of payment.
- **Health works but database routes fail:** `/health` is process-only. Check Render logs (without sharing secrets) and Supabase project URL/key and schema.
- **Render build fails:** verify `package-lock.json` exists and matches `package.json`; use `npm ci`.
