# GitHub upload without overwriting the frontend

**Recommended:** create a new repository called `kwachaLink-backend`. This keeps the existing GitHub Pages site/repository unchanged.

On Android tablet:
1. Download `KwachaLink_Complete_Backend.zip` from this chat and extract it using your file manager.
2. Open the extracted `KwachaLink_Complete_Backend` folder. Upload the files and folders inside it (`README.md`, `package.json`, `src/`, `supabase/`, etc.) to the root of the new backend repository. Do not upload `node_modules`, `.env`, or the ZIP as the only file.
3. If GitHub's web upload interface cannot upload a folder tree on your device, upload files in batches or use GitHub's supported mobile/browser workflow. Preserve the directory structure exactly.
4. Do not put backend files into the existing `kwachaLink` GitHub Pages repository root: that can clutter or disrupt the frontend. If you prefer one repository, put the backend in a new `backend/` subfolder and set Render's Root Directory to `backend`, but ensure the frontend repository stays otherwise intact.
5. Verify `package.json`, `src/server.js`, `supabase/migrations/`, and `render.yaml` appear in GitHub.
