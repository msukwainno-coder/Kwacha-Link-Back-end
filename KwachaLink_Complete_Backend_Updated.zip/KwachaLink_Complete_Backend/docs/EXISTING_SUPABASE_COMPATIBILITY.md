# Existing Supabase schema compatibility

This backend version is adjusted to the existing KwachaLink Supabase tables inspected during setup. It does **not** run migrations automatically and does not drop or recreate tables.

## Existing columns used

- `offers`: `id`, `user_id`, `offer_type`, `currency_from`, `currency_to`, `exchange_rate`, `amount`, `remaining_amount`, `country`, `description`, `status`, `created_at`
- `profiles`: `id`, `full_name`, `email`, `phone`, `country`, `bio`, `avatar_url`, `verification_status`, `created_at`
- `subscriptions`: `id`, `user_id`, `plan_name`, `amount_mwk`, `status`, `starts_at`, `expires_at`, `payment_reference`, `created_at`
- `connections`: `id`, `offer_id`, `requester_id`, `offer_owner_id`, `status`, `created_at`
- `messages`: `id`, `connection_id`, `sender_id`, `message_text`, `created_at`
- `deals`: `id`, `connection_id`, `amount`, `currency`, `status`, `buyer_confirmed`, `seller_confirmed`, `completed_at`, `created_at`
- `reviews`: `id`, `deal_id`, `reviewer_id`, `reviewee_id`, `rating`, `comment`, `created_at`

## Important security and release notes

1. Keep Supabase Row Level Security enabled. The API uses the caller's access token for ordinary database operations so RLS applies.
2. Never put `SUPABASE_SECRET_KEY` in the frontend or a public repository. Configure it only in Render if the restricted manual-admin activation endpoint is needed.
3. Set `ADMIN_USER_IDS` in Render to the exact Supabase Auth UUID(s) authorized for manual activation. Set the same IDs only for trusted administrators.
4. Subscription requests are created as `pending`. The API does not verify Airtel Money/TNM Mpamba payments automatically. Do not activate a subscription merely because a user supplied a payment reference; verify payment through an auditable admin process until a payment provider webhook is implemented.
5. The current database schema has no `buyer_id`/`seller_id` columns on deals, no recipient/read-state columns on messages, and no `updated_at` columns. The API therefore derives connection participants from `connections`, uses `message_text`, and does not write those absent columns.
6. Deal confirmation writes the participant's confirmation flag and marks the deal completed only when both flags are true. Because the current schema has no stored buyer/seller IDs and this implementation does not use a database transaction/RPC, deploy to a test environment first and review race conditions and offer-balance updates before real-money use.
7. This archive is a compatibility update, not a claim that every marketplace workflow has been production-audited. Run the tests after installing dependencies and test with non-production accounts before public launch.

## Render deployment

Build command: `npm install`
Start command: `npm start`
Root directory: `KwachaLink_Complete_Backend` only if the repository contains this extracted folder as its root child; otherwise leave Root Directory blank when deploying the extracted project as the repository root.

Required environment variables: `SUPABASE_URL`, `SUPABASE_PUBLISHABLE_KEY`. Set `CORS_ORIGINS` to the frontend origin. `SUPABASE_SECRET_KEY` and `ADMIN_USER_IDS` are optional and server-only.
