# Database schema and compatibility

## Mandatory first step
Run `supabase/inspect_schema.sql` before migrations. It reports columns/types/defaults, constraints/FKs, indexes, RLS flags, and policies for the seven expected public tables. The current live schema has not been inspected from this build environment, so compatibility is not claimed.

Migrations 001–007 use `CREATE TABLE IF NOT EXISTS` and `ADD COLUMN IF NOT EXISTS` to preserve existing rows and avoid table drops. This does not automatically repair incompatible existing types, missing historical values, incompatible IDs, or old policies. A pre-existing table with different semantics may cause later indexes, constraints, or application queries to fail. Review output and backup first; reconcile manually with a new additive migration.

## Expected columns
- profiles: id references auth.users; display_name, bio, country, preferred_currency, avatar_url, private_contact JSONB, created_at, updated_at.
- offers: owner_id; direction buy/sell; currencies; numeric(20,8) rate; numeric(20,2) original/remaining amounts; description/location/status/timestamps.
- connections: requester_id, offer_owner_id, offer_id, state and timestamps.
- messages: connection_id, sender_id, recipient_id, content, is_read, created_at.
- deals: offer/connection/buyer/seller references; agreed currencies/rate/amount; separate confirmation timestamps; status/timestamps.
- subscriptions: user, plan, status, dates, payment reference, provider metadata, activation method, timestamps.
- reviews: reviewer/reviewed user, completed deal, rating, comment, created_at; unique reviewer/deal.

Migrations 008 add indexes; 009 enables RLS and creates named policies only if absent; 010 adds atomic deal confirmation/cancellation functions; 011 creates profile rows for new Auth users. Existing policies with other names remain, so inspect and evaluate all policies for overly permissive access. The API's subscription admin activation uses a server-only secret key and allowlist; a verified payment-provider webhook is not implemented.
