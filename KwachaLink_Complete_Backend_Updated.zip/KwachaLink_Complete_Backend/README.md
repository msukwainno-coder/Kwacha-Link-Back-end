# KwachaLink Backend

Node.js + Express REST API for the KwachaLink Malawi currency-exchange marketplace. Uses Supabase Auth and the caller's access token for ordinary database access, keeping Row Level Security in force.

## Features

- Health endpoint
- Offer listing, filtering, creation, updates, pause/resume/cancel
- Profile read/update
- Connection requests and accept/reject/cancel
- Connection messaging
- Deal records, two-party completion confirmations, cancellation and dispute status
- Monthly subscription requests at MK 4,999 and subscriber contact-access check
- Reviews for completed deals
- Request validation, rate limiting, security headers, CORS and centralized errors

## Install and run

1. Use Node.js 20 or newer.
2. Run `npm install`.
3. Copy `.env.example` to `.env` for local development and enter the Supabase project URL and publishable key. Never commit `.env`.
4. Run `npm start`.
5. Test `GET /health` and `GET /api/v1/offers`.

For Render, set build command to `npm install` and start command to `npm start` in the folder containing this `package.json`.

## API base

`/api/v1`

See `API_DOCUMENTATION.md`, `docs/FRONTEND_INTEGRATION.md`, and `docs/EXISTING_SUPABASE_COMPATIBILITY.md`.

## Important

This version is adapted to the existing Supabase schema documented in the compatibility guide. It is not yet a payment processor and must not be used to claim that a subscription payment was verified automatically. Do not expose the Supabase secret/service-role key to the frontend. Keep RLS enabled and test with non-production accounts before launch.
